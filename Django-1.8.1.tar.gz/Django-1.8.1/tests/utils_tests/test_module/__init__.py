class SiteMock(object):
    _registry = {}
site = SiteMock()
